'''
    Find the total cost of inventory
    Using inventory_cost function
'''
import sys
import csv
from report import read_inventory

def inventory_cost(filename):
    total = 0.0
    inventory = read_inventory(filename)
    for prod in inventory:
        total += prod.quant * prod.price

    return total

def main(argv):
    if len(argv) == 2:
        filename = argv[1]
    else:
        filename = "Data/inventory.csv"

    cost = inventory_cost(filename)
    print("Total cost", cost)

if __name__ == "__main__":
    import sys
    main(sys.argv)
