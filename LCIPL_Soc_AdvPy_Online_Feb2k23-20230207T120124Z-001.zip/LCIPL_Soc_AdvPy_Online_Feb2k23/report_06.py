'''
    Report Table to show the fluctuations in prices of inventory
'''

import csv
from fileparse import parse_csv

def read_prices(filename):
    prices = parse_csv(filename,
                       types=[str, float],
                       has_headers=False
                       )

    return dict(prices)


def read_inventory(filename):
    inventory = parse_csv(filename,
                          select=['name', 'quant', 'price'],
                          types=[str, int, float]
                          )
    return inventory

def make_report(inventory, prices):
    report = list()
    for prod in inventory:
        name = prod['name']
        quant = prod['quant']
        latest_price = prices[name]
        change = latest_price - prod['price']
        report.append( (name, quant, latest_price, change) )

    return report

def print_report(report):
    headers = ('Name', 'Quantity', 'Price', 'Change')
    print('%10s %10s %10s %10s' % headers)

    sep = ['-' * 10] * 4
    print('%10s %10s %10s %10s' % tuple(sep))

    for r in report:
        print('%10s %10d %10.2f %10.2f' % r)

def inventory_report(inventory_filename, prices_filename):
    inventory = read_inventory(inventory_filename)
    latest_prices = read_prices(prices_filename)
    report = make_report(inventory, latest_prices)
    print_report(report)

# Main
if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        raise SystemExit(f'Usage: {sys.argv[0]} invfile pricefile')

    invfile = sys.argv[1]
    pricefile = sys.argv[2]

    inventory_report(invfile, pricefile)
