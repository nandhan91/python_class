'''
    Report gain or loss in inventory
'''

import csv

def read_prices(filename):
    prices = dict()
    with open(filename) as FH:
        data = csv.reader(FH)
        for row in data:
            try:
                prices[row[0]] = float(row[1])
            except IndexError as e:
                continue

    return prices


def read_inventory(filename):
    inventory = list()
    with open(filename) as FH:
        data = csv.reader(FH)
        headers = next(FH)
        for row in data:
            prod = {
                    'name'  : row[0],
                    'quant' : int(row[1]),
                    'price' : float(row[2]),
                }
            inventory.append(prod)

    return inventory
