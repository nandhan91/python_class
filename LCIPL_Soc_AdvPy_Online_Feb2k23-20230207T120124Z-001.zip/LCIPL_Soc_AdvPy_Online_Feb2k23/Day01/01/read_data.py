'''
    Read the contents of a file
'''

with open("../Data/inventory.csv") as FH:
    for line in FH:
        print(line, end='')
