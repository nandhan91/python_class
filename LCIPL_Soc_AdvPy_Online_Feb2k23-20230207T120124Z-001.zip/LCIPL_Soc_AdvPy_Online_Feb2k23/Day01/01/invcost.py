'''
    Find the total cost of inventory
'''
import csv

total = 0.0
with open("../Data/inventory.csv") as FH:
    data = csv.reader(FH)
    headers = next(data)
    for row in data:
        #parts = line.split(',')
        quant = int(row[1])
        price = float(row[2])
        total += quant * price

print("Total cost", total)
