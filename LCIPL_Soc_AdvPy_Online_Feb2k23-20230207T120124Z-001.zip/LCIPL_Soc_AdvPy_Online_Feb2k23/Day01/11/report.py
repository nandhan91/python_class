'''
    Report gain or loss in inventory
'''

import csv

def read_prices(filename):
    prices = dict()
    with open(filename) as FH:
        data = csv.reader(FH)
        for row in data:
            try:
                prices[row[0]] = float(row[1])
            except IndexError as e:
                continue

    return prices


def read_inventory(filename):
    inventory = list()
    with open(filename) as FH:
        data = csv.reader(FH)
        headers = next(data)
        for row in data:
            record = dict(zip(headers, row))
            prod = {
                    'name'  : record['name'],
                    'quant' : int(record['quant']),
                    'price' : float(record['price']),
                }
            inventory.append(prod)

    return inventory

def make_report(inventory, prices):
    report = list()
    for prod in inventory:
        name = prod['name']
        quant = prod['quant']
        latest_price = prices[name]
        change = latest_price - prod['price']
        report.append( (name, quant, latest_price, change) )

    return report

# Main
inventory = read_inventory("../Data/inventory.csv")
latest_prices = read_prices("../Data/prices.csv")
report = make_report(inventory, latest_prices)

headers = ('Name', 'Quantity', 'Price', 'Change')
print('%10s %10s %10s %10s' % headers)

sep = ['-' * 10] * 4
print('%10s %10s %10s %10s' % tuple(sep))

for r in report:
    print('%10s %10d %10.2f %10.2f' % r)

## # Find if there is loss or gain in inventory
## inventory = read_inventory("../Data/inventory.csv")
## total_cost = 0.0 
## for prod in inventory:
##     total_cost += prod['quant'] * prod['price']
##                                                                                  
## latest_prices = read_prices("../Data/prices.csv")
## latest_cost = 0.0 
## for prod in inventory:
##     latest_cost += prod['quant'] * latest_prices[prod['name']]
## 
## profit = round(latest_cost - total_cost, 2)
## print("Total Gain/Loss", profit)

