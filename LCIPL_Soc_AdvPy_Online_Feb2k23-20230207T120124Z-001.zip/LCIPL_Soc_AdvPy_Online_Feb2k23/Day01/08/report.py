'''
    Report gain or loss in inventory
'''

import csv

def read_prices(filename):
    prices = dict()
    with open(filename) as FH:
        data = csv.reader(FH)
        for row in data:
            try:
                prices[row[0]] = float(row[1])
            except IndexError as e:
                continue

    return prices


def read_inventory(filename):
    inventory = list()
    with open(filename) as FH:
        data = csv.reader(FH)
        headers = next(FH)
        for row in data:
            prod = {
                    'name'  : row[0],
                    'quant' : int(row[1]),
                    'price' : float(row[2]),
                }
            inventory.append(prod)

    return inventory


# Main
# Find if there is loss or gain in inventory
inventory = read_inventory("../Data/inventory.csv")
total_cost = 0.0 
for prod in inventory:
    total_cost += prod['quant'] * prod['price']
                                                                                 
latest_prices = read_prices("../Data/prices.csv")
latest_cost = 0.0 
for prod in inventory:
    latest_cost += prod['quant'] * latest_prices[prod['name']]

profit = round(latest_cost - total_cost, 2)
print("Total Gain/Loss", profit)

