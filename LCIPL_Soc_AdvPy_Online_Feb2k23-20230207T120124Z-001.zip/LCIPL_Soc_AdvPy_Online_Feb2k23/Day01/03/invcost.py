'''
    Find the total cost of inventory
    Using inventory_cost function
'''
import sys
import csv

def inventory_cost(filename):
    total = 0.0
    with open(filename) as FH:
        data = csv.reader(FH)
        headers = next(data)
        for row in data:
            #parts = line.split(',')
            quant = int(row[1])
            price = float(row[2])
            total += quant * price

    return total

if len(sys.argv) == 2:
    filename = sys.argv[1]
else:
    filename = "../Data/inventory.csv"

cost = inventory_cost(filename)
print("Total cost", cost)
