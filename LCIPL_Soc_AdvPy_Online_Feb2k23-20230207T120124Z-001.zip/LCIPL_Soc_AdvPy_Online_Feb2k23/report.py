'''
    Report Table to show the fluctuations in prices of inventory
'''

import csv
from fileparse import parse_csv
from product import Product
from tableformat import create_formatter

def read_prices(filename):
    with open(filename) as FH:
        prices = parse_csv(FH,
                           types=[str, float],
                           has_headers=False
                           )

    return dict(prices)


def read_inventory(filename):
    with open(filename) as FH:
        inv_dicts = parse_csv(FH,
                              select=['name', 'quant', 'price'],
                              types=[str, int, float]
                              )
        inventory = [ Product(p['name'], p['quant'], p['price'])  
                      for p in inv_dicts
                    ] 
    return inventory

def make_report(inventory, prices):
    report = list()
    for prod in inventory:
        name = prod.name
        quant = prod.quant
        latest_price = prices[name]
        change = latest_price - prod.price
        report.append( (name, quant, latest_price, change) )

    return report

def print_report(report, formatter):
    headers = ('Name', 'Quantity', 'Price', 'Change')
    formatter.headings(headers)
    #print('%10s %10s %10s %10s' % headers)

    #sep = ['-' * 10] * 4
    #print('%10s %10s %10s %10s' % tuple(sep))

    #for r in report:
    for name,quant,price,change in report:
        rowdata = [name, str(quant), f'{price:0.2f}', f'{change:0.2f}']
        formatter.row(rowdata)
        #print('%10s %10d %10.2f %10.2f' % r)

def inventory_report(inventory_filename, prices_filename, fmt='txt'):
    inventory = read_inventory(inventory_filename)
    latest_prices = read_prices(prices_filename)
    report = make_report(inventory, latest_prices)
    formatter = create_formatter(fmt)

    print_report(report, formatter)


def main(argv):
    if len(argv) < 3:
        raise SystemExit(f'Usage: {argv[0]} invfile pricefile [fmt]')

    invfile = argv[1]
    pricefile = argv[2]
    try :
        fmt = argv[3]
    except IndexError as e:
        fmt = 'txt'

    inventory_report(invfile, pricefile, fmt)

# Main
if __name__ == "__main__":
    import sys
    main(sys.argv)
